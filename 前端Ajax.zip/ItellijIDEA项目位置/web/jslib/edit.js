//在页面装载的时候进行对td的点击
$(document).ready(function () {
    var tds = $("td");
    tds.click(tdclick);
});
function tdclick() {
        //1将文本的内容保存起来
        var td = $(this);
        var text = td.text();
        //2清空td里面的内容
        td.html("");
        //3建立文本框
        var input = $("<input>");
        //4.设置文本框的值是保存起来的值
        input.attr("value", text);
        //4.5相应回车和键盘事件
        input.keyup(function (event) {
            //判断按键是什么
            var myevent = event || window.event;
            var key = myevent.keyCode;
            if (key == 13) {
                var inputnode = $(this);
                //1.保存文本框的内荣
                var inputtext = inputnode.val();
                //2.清空td里面的内容保存的文本框填充到td中去
                var tdNode = inputnode.parent();
                tdNode.html(inputtext);
                //4.让td重新拥有点击事件
                td.click(tdclick);
            }
        });
        //5将文本框加入到td中
        td.append(input);
        //6为了防止td的点击事件，我们可以移除
        td.unbind("click");
}