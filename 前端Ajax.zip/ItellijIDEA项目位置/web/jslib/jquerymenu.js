//按主菜单子菜单会显示或者消失
//在页面装载的时候给所有的主菜单进行onclick事件

//注册页面在装载的时候执行的方法

$(document).ready( function(){
    //先找所有的主菜单，然后给他们进行点击事件
    var as = $("ul").children("a");
    //或者是var uls  = $("ul > a");
    as.click(
        function(){
            var aNode = $(this);

            //找到相应的兄弟节点
            var lis = aNode.nextAll("li");
            //切换菜单当前的状态toggle
            lis.toggle("show");
        }
    );
} );