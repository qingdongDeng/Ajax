function showWin(){
    var winNode = $("#win");
//通过jqurey修改css
    //winNode.css("display","block");
//使用jquery的show方法
    winNode.fadeIn("slow");//淡入淡出fadeOut
//winNode.show(4000);
}
function hide(){
    var Node = $("#win");
    //Node.css("display","none");
    Node.hide("slow");
    //或者是fadeout淡出
}