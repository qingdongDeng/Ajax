import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.sql.rowset.serial.SerialException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.HashMap;


/**
 * Created by Dqd on 2016/11/5.
 */
public class GetStockServlet extends javax.servlet.http.HttpServlet {

    //保存股票对象map
    private HashMap<String,Stock>stocks;

    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        double sz = 0;
        double pf = 0;
        sz = 20*Math.random();
        pf = 0.5*Math.random();

        double tmp1 = Math.random();

        Stock st1 = stocks.get("30000001");
        Stock st2 = stocks.get("30200001");
        if(tmp1>=0.5){
             sz = st1.getNow()+sz;
             pf = st2.getNow()-pf;
        }else{
            sz = st1.getNow()-sz;
            pf = st2.getNow()+pf;
        }
/*        DecimalFormat df = new DecimalFormat("0.00");
        String sz1 = df.format(sz);
        String pf1 = df.format(pf); */
        sz = (int)(sz*100)/100.0;
        pf = (int)(pf*100)/100.0;
        st1.setNow(sz);
        st2.setNow(pf);
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        //out.println(st1+"<br/>"+st2);
        StringBuilder sb = new StringBuilder();
        sb.append("[{name:\"").append(st1.getName())
                .append("\",id:\"").append(st1.getId())
        .append("\",yes:").append(st1.getYesterday())
                .append(",");


    }

    @Override
    public void init(ServletConfig servletConfig)throws ServletException{
        stocks = new HashMap<String,Stock>();
        Stock st = new Stock(3000,2990,"汁水","30000001",201);
        Stock st2 = new Stock(3010,1990,"水","30200001",227);

        stocks.put(st.getId(),st);
        stocks.put(st2.getId(),st2);

        System.out.println(stocks);
    }
}
